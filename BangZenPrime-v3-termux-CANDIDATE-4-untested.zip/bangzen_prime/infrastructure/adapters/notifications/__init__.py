"""Outbound notification adapters."""
